package com.cart3r.exam

data class AiReply(
    val answer: String,
    val explanation: String
)

data class ExamRecord(
    val timestamp: Long,
    val subject: String,
    val total: Int,
    val correct: Int,
    val score: Double,
    val passed: Boolean
)
