package com.cart3r.exam

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val ocr = OcrReader()
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var question: EditText
    private lateinit var output: TextView
    private lateinit var apiUrl: EditText
    private lateinit var appToken: EditText
    private lateinit var history: HistoryStore
    private val pickImage = 71
    private val screenCaptureRequest = 72
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    @Volatile private var captureArmed = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        history = HistoryStore(this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(0xFF09090D.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("CART3R.EXAM AI", 27, 0xFFFF405B.toInt(), true))
        content.addView(text("AI STUDY • PRACTICE • SCORE TRACKER", 11, 0xFFB8AAB0.toInt()))
        content.addView(gap(18))
        content.addView(text("AI BACKEND URL", 12, 0xFFFF7185.toInt(), true))
        apiUrl = EditText(this).apply {
            setText(getSharedPreferences("config", 0).getString("api_url", "https://YOUR-SERVER.example.com"))
            setTextColor(-1); setHintTextColor(0xFF9D9298.toInt())
            hint = "https://your-backend.example.com"
            setSingleLine(true)
            setBackgroundColor(0xFF21151C.toInt())
        }
        content.addView(apiUrl)
        content.addView(text("APP ACCESS TOKEN", 12, 0xFFFF7185.toInt(), true))
        appToken = EditText(this).apply {
            setText(getSharedPreferences("config", 0).getString("app_token", ""))
            setTextColor(-1); setHintTextColor(0xFF9D9298.toInt())
            hint = "Token yang sama dengan APP_TOKEN di backend"
            setSingleLine(true)
            setBackgroundColor(0xFF21151C.toInt())
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        content.addView(appToken)
        content.addView(button("SAVE SERVER SETTINGS") {
            val endpoint = apiUrl.text.toString().trim()
            if (!endpoint.startsWith("https://")) { toast("URL backend harus menggunakan HTTPS"); return@button }
            getSharedPreferences("config", 0).edit()
                .putString("api_url", endpoint)
                .putString("app_token", appToken.text.toString().trim()).apply()
            toast("Server settings saved")
        })
        content.addView(gap(14))
        content.addView(text("QUESTION INPUT", 15, 0xFFFF526B.toInt(), true))
        question = EditText(this).apply {
            minLines = 5
            gravity = Gravity.TOP
            hint = "Ketik atau tempel soal di sini..."
            setTextColor(-1); setHintTextColor(0xFF9D9298.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF21151C.toInt())
        }
        content.addView(question, LinearLayout.LayoutParams(-1, -2))
        content.addView(button("PILIH GAMBAR SOAL • OCR") {
            startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), pickImage)
        })
        content.addView(button("BAGIKAN LAYAR & BACA SOAL") { confirmScreenCapture() })
        content.addView(text("Screen share hanya dimulai setelah persetujuan Android. CART3R mengambil satu cuplikan saat diminta, bukan merekam terus-menerus. Lanjutkan hanya pada latihan atau asesmen yang mengizinkan AI.", 11, 0xFFB8AAB0.toInt()))
        content.addView(button("BAHAS SOAL DENGAN AI") { askAi() })
        output = text("Hasil pembahasan akan tampil di sini.", 14, -1)
        output.setPadding(14, 14, 14, 14)
        output.setBackgroundColor(0xFF171118.toInt())
        content.addView(output)
        content.addView(gap(18))
        content.addView(text("KALKULATOR NILAI • KKM 75", 17, 0xFFFF526B.toInt(), true))
        val total = EditText(this).apply { hint = "Jumlah soal"; setText("40"); inputType = 2; setTextColor(-1) }
        val correct = EditText(this).apply { hint = "Jawaban benar"; setText("30"); inputType = 2; setTextColor(-1) }
        content.addView(total); content.addView(correct)
        content.addView(button("HITUNG & SIMPAN NILAI") {
            val t = total.text.toString().toIntOrNull() ?: 0
            val c = correct.text.toString().toIntOrNull() ?: -1
            if (t <= 0 || c < 0 || c > t) { toast("Masukkan jumlah soal dan jawaban benar yang valid"); return@button }
            val score = c.toDouble() / t * 100.0
            val passed = score >= 75.0
            history.add(ExamRecord(System.currentTimeMillis(), "Latihan", t, c, score, passed))
            output.text = "Nilai: %.2f\n%s (KKM 75)".format(Locale.US, score, if (passed) "LULUS" else "BELUM LULUS")
            showHistory(content)
        })
        content.addView(button("RIWAYAT NILAI") { showHistory(content) })
        content.addView(button("FLOATING STUDY PANEL") { requestOverlay() })
        content.addView(text("Floating panel hanya untuk sesi belajar atau ujian yang mengizinkan bantuan AI. Tidak membaca aplikasi lain secara diam-diam.", 11, 0xFFB8AAB0.toInt()))
        setContentView(root)
    }


    private fun confirmScreenCapture() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Bagikan layar untuk OCR")
            .setMessage("Fitur ini mengambil satu cuplikan layar setelah kamu menyetujui dialog sistem Android. Gunakan hanya untuk latihan atau asesmen yang secara jelas mengizinkan bantuan AI. Lanjutkan?")
            .setNegativeButton("BATAL", null)
            .setPositiveButton("LANJUTKAN") { _, _ ->
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), screenCaptureRequest)
            }
            .show()
    }

    private fun captureOneFrame(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { releaseCapture() }
            }, mainHandler)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (!captureArmed) { image.close(); return@setOnImageAvailableListener }
                captureArmed = false
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val paddedBitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    paddedBitmap.copyPixelsFromBuffer(buffer)
                    val bitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height)
                    paddedBitmap.recycle()
                    runOnUiThread {
                        output.text = "Membaca teks dari cuplikan layar..."
                        ocr.read(bitmap, ContextCompat.getMainExecutor(this)) { result, error ->
                            bitmap.recycle()
                            if (error != null) {
                                output.text = "OCR gagal: ${error.message}"
                            } else if (result.isNullOrBlank()) {
                                output.text = "Tidak ditemukan teks. Pastikan soal terlihat dan tidak dilindungi aplikasi."
                            } else {
                                question.setText(result)
                                output.text = "Teks berhasil dibaca. Mengirim soal ke AI..."
                                askAi()
                            }
                            releaseCapture()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread { output.text = "Gagal memproses cuplikan: ${e.message}"; releaseCapture() }
                } finally {
                    image.close()
                }
            }, mainHandler)
            virtualDisplay = projection?.createVirtualDisplay(
                "CART3R-OneShot-Capture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, mainHandler
            )
            output.text = "Berbagi layar aktif. Pindah ke halaman soal sekarang; cuplikan diambil dalam 5 detik..."
            mainHandler.postDelayed({
                if (imageReader != null && projection != null) {
                    captureArmed = true
                    output.text = "Mengambil cuplikan layar soal..."
                }
            }, 5000)
        } catch (e: Exception) {
            output.text = "Screen capture tidak tersedia: ${e.message}"
            releaseCapture()
        }
    }

    private fun releaseCapture() {
        captureArmed = false
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() }
        imageReader = null
        val activeProjection = projection
        projection = null
        runCatching { activeProjection?.stop() }
    }

    private fun askAi() {
        val q = question.text.toString().trim()
        if (q.isEmpty()) { toast("Masukkan soal atau gunakan OCR terlebih dahulu"); return }
        val base = apiUrl.text.toString().trim()
        val token = appToken.text.toString().trim()
        if (!base.startsWith("https://")) { toast("Gunakan URL backend HTTPS yang valid"); return }
        if (token.isBlank()) { toast("Isi APP ACCESS TOKEN sesuai konfigurasi backend"); return }
        output.text = "Menghubungi AI..."
        Thread {
            try {
                val reply = AiClient(base, token).explain(q)
                runOnUiThread { output.text = "JAWABAN USULAN\n${reply.answer}\n\nPEMBAHASAN\n${reply.explanation}" }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Gagal menghubungi AI: ${e.message}\nPeriksa server URL dan koneksi internet." }
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == screenCaptureRequest) {
            if (resultCode == Activity.RESULT_OK && data != null) captureOneFrame(resultCode, data)
            else toast("Izin berbagi layar dibatalkan")
        }
        if (requestCode == pickImage && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val bitmap: Bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                output.text = "Membaca gambar..."
                ocr.read(bitmap, ContextCompat.getMainExecutor(this)) { result, error ->
                    if (error != null) toast("OCR gagal: ${error.message}")
                    else question.setText(result ?: "")
                }
            } catch (e: Exception) { toast("Gagal membuka gambar: ${e.message}") }
        }
    }

    private fun showHistory(container: LinearLayout) {
        val records = history.all()
        val lines = records.take(20).joinToString("\n") {
            val date = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(it.timestamp))
            "$date • ${it.subject} • %.1f • %s".format(Locale.US, it.score, if (it.passed) "LULUS" else "BELUM")
        }
        output.text = if (lines.isBlank()) "Belum ada riwayat nilai." else "RIWAYAT TERBARU\n$lines"
    }

    private fun requestOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Aktifkan izin tampil di atas aplikasi lain, lalu buka kembali fitur ini.")
        } else {
            startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 5, 0, 5) }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(-1); setBackgroundColor(0xFF9D1732.toInt())
        setOnClickListener { action() }
    }

    private fun gap(dp: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        releaseCapture()
        worker.shutdown()
        super.onDestroy()
    }
}
