package com.cart3r.exam

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiClient(private val baseUrl: String, private val appToken: String) {
    fun explain(question: String): AiReply {
        val url = URL(baseUrl.trimEnd('/') + "/api/explain")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $appToken")
        }
        try {
            val body = JSONObject().put("question", question).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = runCatching { JSONObject(responseText) }.getOrNull()
            if (status !in 200..299) {
                val message = json?.optString("error")?.takeIf { !it.isNullOrBlank() }
                    ?: "Server returned HTTP $status"
                throw IllegalStateException(message)
            }
            val result = json ?: throw IllegalStateException("Respons backend bukan JSON yang valid")
            return AiReply(
                result.optString("answer", "Jawaban belum tersedia"),
                result.optString("explanation", "Pembahasan belum tersedia")
            )
        } finally {
            conn.disconnect()
        }
    }
}
