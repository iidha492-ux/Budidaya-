# CART3R.EXAM AI

Android study/practice app with OCR, AI explanations, KKM score calculator, local score history, and an explicit floating study panel.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Android 7.0+ device (API 24+)
- Node.js 18+ for backend
- AI provider API key

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
5. For a release APK, configure a signing key in Android Studio and choose Generate Signed Bundle / APK.
6. This project builds a single APK with Android's normal ABI handling; do not split APKs if you want one installable universal APK.

## Backend setup
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env`.
4. Set `APP_TOKEN`, `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL`. Generate a long random `APP_TOKEN`, then enter exactly the same value in the Android app under **APP ACCESS TOKEN**. Keep the provider key only on the backend.
5. Run `npm start`.
6. Deploy behind HTTPS. Put the HTTPS backend URL into the app's AI BACKEND URL field.

Never put the AI provider secret in the Android app. The backend is a starter; configure a strong private `APP_TOKEN`, deploy only behind HTTPS, add user-specific authentication and quotas before public deployment, and avoid logging student question content.

## Included features
- User-selected image import and on-device ML Kit text recognition (OCR).
- Explicit Android MediaProjection consent flow for a single user-initiated screen capture; the app waits 5 seconds so the user can switch to a permitted practice question, runs on-device OCR, then submits recognized text to the configured AI backend.
- Manual question entry.
- AI answer proposal and structured learning explanation through your backend.
- Backend bearer-token check, basic request rate limiting, security headers, and HTTPS-only app endpoint validation.
- Score calculator: correct / total * 100; KKM fixed at 75.
- Local score history using app-private SharedPreferences.
- Explicit overlay study panel, requiring Android's user-granted "Display over other apps" permission.

## Responsible use
Use AI assistance only for practice or assessments that explicitly permit it. The overlay does not capture another app's screen, read exam content in the background, automate answer entry, or bypass proctoring. Questions must be entered or images selected by the user.

## Compatibility notes
- Minimum Android version: 7.0 (API 24).
- Overlay behavior and permission screens vary by device manufacturer and Android release.
- ML Kit OCR uses Google Play services/model delivery behavior; first use may require internet.
- Target SDK 28 is chosen for broad compatibility in this starter. Review and update target SDK and permission behavior before publishing to Google Play.
- No API key is included. No APK is prebuilt or claimed tested.
