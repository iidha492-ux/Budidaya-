require("dotenv").config();
const crypto = require("node:crypto");
const express = require("express");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "64kb" }));

const explainLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Terlalu banyak permintaan. Coba lagi sebentar." }
});

function requireAppToken(req, res, next) {
  const expected = process.env.APP_TOKEN || "";
  const supplied = (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!expected || !supplied) return res.status(401).json({ error: "APP_TOKEN tidak valid atau belum dikonfigurasi." });
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Akses ditolak. Periksa APP ACCESS TOKEN." });
  }
  next();
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "CART3R.EXAM AI" }));

app.post("/api/explain", explainLimiter, requireAppToken, async (req, res) => {
  try {
    const question = String(req.body?.question || "").trim();
    if (!question || question.length > 12000) {
      return res.status(400).json({ error: "Soal harus berisi 1-12000 karakter." });
    }
    if (!process.env.AI_API_KEY) return res.status(503).json({ error: "AI_API_KEY belum dikonfigurasi." });

    const endpoint = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "") + "/chat/completions";
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "Kamu tutor pendidikan untuk latihan dan asesmen yang secara eksplisit mengizinkan bantuan AI. Balas HANYA JSON valid dengan properti answer dan explanation. answer berisi jawaban akhir yang jelas. explanation berisi konsep, langkah penyelesaian ringkas, dan alasan. Jika soal ambigu atau informasi kurang, katakan secara jujur dan jangan mengarang." },
          { role: "user", content: question }
        ]
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: data.error?.message || "Permintaan ke penyedia AI gagal." });
    const content = data.choices?.[0]?.message?.content || "{}";
    let parsed;
    try { parsed = JSON.parse(content); }
    catch { parsed = { answer: content, explanation: "Periksa kembali jawaban dengan materi pembelajaran." }; }
    return res.json({
      answer: String(parsed.answer || "Jawaban belum tersedia"),
      explanation: String(parsed.explanation || "Pembahasan belum tersedia")
    });
  } catch (_error) {
    return res.status(500).json({ error: "Kesalahan internal backend. Periksa log server." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`CART3R backend listening on ${port}`));
