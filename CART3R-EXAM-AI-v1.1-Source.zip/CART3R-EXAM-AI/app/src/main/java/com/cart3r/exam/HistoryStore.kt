package com.cart3r.exam

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("exam_history", Context.MODE_PRIVATE)

    fun add(record: ExamRecord) {
        val arr = JSONArray(prefs.getString("records", "[]"))
        arr.put(JSONObject().apply {
            put("timestamp", record.timestamp)
            put("subject", record.subject)
            put("total", record.total)
            put("correct", record.correct)
            put("score", record.score)
            put("passed", record.passed)
        })
        prefs.edit().putString("records", arr.toString()).apply()
    }

    fun all(): List<ExamRecord> {
        val arr = JSONArray(prefs.getString("records", "[]"))
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                ExamRecord(o.getLong("timestamp"), o.optString("subject"),
                    o.getInt("total"), o.getInt("correct"), o.getDouble("score"),
                    o.getBoolean("passed"))
            }.getOrNull()
        }.reversed()
    }
}
