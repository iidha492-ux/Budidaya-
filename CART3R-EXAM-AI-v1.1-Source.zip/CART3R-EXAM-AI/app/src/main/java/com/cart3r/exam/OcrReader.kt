package com.cart3r.exam

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executor

class OcrReader {
    fun read(bitmap: Bitmap, executor: Executor, callback: (String?, Exception?) -> Unit) {
        val image = InputImage.fromBitmap(bitmap, 0)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener(executor) { callback(it.text, null) }
            .addOnFailureListener(executor) { callback(null, it) }
    }
}
